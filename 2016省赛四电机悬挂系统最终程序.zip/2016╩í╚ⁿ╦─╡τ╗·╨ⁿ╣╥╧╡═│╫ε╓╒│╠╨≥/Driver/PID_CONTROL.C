/************************************************************************/
/*********                 PID_CONTROL.C                       *************/
/**********          Written By ZQW---20160815              *************/
/**********                  Version 1.4			      ***************/
/************************************************************************/
#include "STC15.H"
#include "DataForm_STC15.H"
#include "PID_CONTROL.H"
#include "KEY.H"

//-----------------------------------------------------------------------
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//-----------------------------------------------------------------------
//----------------------���ݱ�������-------------------------------------
//-----------------------------------------------------------------------
//=======================================================================

//fp32 PID_N=0;
//fp32 PID_P=0;				//p
//fp32 PID_I=0;				//i
//fp32 PID_OUT=0;			    //PID���
//uint8 PID_I_H=30;			//��������
//uint8 PID_I_L=-30;			//��������
//uint8 PID_OUT_H=100;		//�������
//uint8 PID_OUT_L=0;			//�������
//uint8 Kp=80;				//��������
//uint8 Ki=1;					//���ֳ���
//uint8 Target_L=39;			//Ŀ������
//uint8 Target_H=41;			//Ŀ������
fp32 PID_N = 0;
fp32 PID_P = 0;
fp32 PID_I = 0;
fp32 PID_D = 0;
fp32 TEMP_D = 0;
uint8 motora = 0;
uint8 motorb = 0;			

//-----------------------------------------------------------------------
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//-----------------------------------------------------------------------
//----------------------���庯��ʵ��-------------------------------------
//-----------------------------------------------------------------------
//=======================================================================
//PID���ƣ�δ��D΢�ֿ���-------------------------------------------------
//PID_CONTROL(fp32 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
//{
//	PID_N=Value;
//	//--------------------------
//	PID_P=Target-PID_N;
//	//--------------------------
//	PID_I+=PID_P;
//	//--------------------------
//	if(PID_I>=PID_I_H) PID_I=PID_I_H;
//	if(PID_I<=PID_I_L) PID_I=PID_I_L;
//	//--------------------------
//	PID_OUT=PID_P*Kp+PID_I*Ki;					  //�����ͻ��֣�δ��΢�ֿ���
//	//--------------------------
//	if(PID_OUT>PID_OUT_H) PID_OUT=PID_OUT_H;
//	if(PID_OUT<=PID_OUT_L) PID_OUT=PID_OUT_L;
//	//-----------------------------
//	if(Target_L<=PID_OUT<=Target_H)	 PID_OUT=0;	  //����Ŀ�����䣬ֹͣ����
//	return(PID_OUT);		
//}


void PID_CONTROL_9085(fp32 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
{
	PID_N=Value;
	//--------------------------
	PID_P=Target-PID_N;
	//--------------------------
	PID_I+=PID_P;
	//--------------------------
	if(PID_I>=20) PID_I=20;
	if(PID_I<=-20) PID_I=-20;
	//--------------------------
	motorb = (int)(44+( PID_P*0.07+PID_I*0.01));	
	motora = (int)(39-( PID_P*0.07+PID_I*0.01));
	//--------------------------
	if(motorb>=50) motorb=50;
	if(motorb<=10) motorb=10;
	if(motora>=50) motora=50;
	if(motora<=10) motora=10;	
} 

void PID_CONTROL_8580(fp32 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
{
	PID_N=Value;
	//--------------------------
	PID_P=Target-PID_N;
	//--------------------------
	PID_I+=PID_P;
	//--------------------------
	if(PID_I>=20) PID_I=20;
	if(PID_I<=-20) PID_I=-20;
	//--------------------------
	motorb = (int)(42+( PID_P*0.07+PID_I*0.01));	
	motora = (int)(39-( PID_P*0.07+PID_I*0.01));
	//--------------------------
	if(motorb>=50) motorb=50;
	if(motorb<=10) motorb=10;
	if(motora>=50) motora=50;
	if(motora<=10) motora=10;	
} 

void PID_CONTROL_8075(fp32 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
{
	PID_N=Value;
	//--------------------------
	PID_P=Target-PID_N;
	//--------------------------
	PID_I+=PID_P;
	//--------------------------
	if(PID_I>=20) PID_I=20;
	if(PID_I<=-20) PID_I=-20;
	//--------------------------
	motorb = (int)(42+( PID_P*0.07+PID_I*0.01));	
	motora = (int)(40-( PID_P*0.07+PID_I*0.01));
	//--------------------------
	if(motorb>=50) motorb=50;
	if(motorb<=10) motorb=10;
	if(motora>=50) motora=50;
	if(motora<=10) motora=10;	
} 

void PID_CONTROL_7570(fp32 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
{
	PID_N=Value;
	//--------------------------
	PID_P=Target-PID_N;
	//--------------------------
	PID_I+=PID_P;
	//--------------------------
	if(PID_I>=20) PID_I=20;
	if(PID_I<=-20) PID_I=-20;
	//--------------------------
	motorb = (int)(39+( PID_P*0.07+PID_I*0.01));	
	motora = (int)(41-( PID_P*0.07+PID_I*0.01));
	//--------------------------
	if(motorb>=50) motorb=50;
	if(motorb<=10) motorb=10;
	if(motora>=50) motora=50;
	if(motora<=10) motora=10;	
}

void PID_CONTROL_7065(fp32 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
{
	PID_N=Value;
	//--------------------------
	PID_P=Target-PID_N;
	//--------------------------
	PID_I+=PID_P;
	//--------------------------
	if(PID_I>=20) PID_I=20;
	if(PID_I<=-20) PID_I=-20;
	//--------------------------
	motorb = (int)(39+( PID_P*0.05+PID_I*0.01));	
	motora = (int)(45-( PID_P*0.05+PID_I*0.01));
	//--------------------------
	if(motorb>=50) motorb=50;
	if(motorb<=10) motorb=10;
	if(motora>=50) motora=50;
	if(motora<=10) motora=10;	
}

void PID_CONTROL_6560(fp32 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
{
	PID_N=Value;
	//--------------------------
	PID_P=Target-PID_N;
	//--------------------------
	PID_I+=PID_P;
	//--------------------------
	if(PID_I>=20) PID_I=20;
	if(PID_I<=-20) PID_I=-20;
	//--------------------------
	motorb = (int)(34+( PID_P*0.06+PID_I*0.01));	
	motora = (int)(46-( PID_P*0.07+PID_I*0.01));
	//--------------------------
	if(motorb>=50) motorb=50;
	if(motorb<=10) motorb=10;
	if(motora>=50) motora=50;
	if(motora<=10) motora=10;	
}

void PID_CONTROL_6055(fp32 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
{
	PID_N=Value;
	//--------------------------
	PID_P=Target-PID_N;
	//--------------------------
	PID_I+=PID_P;
	//--------------------------
	if(PID_I>=20) PID_I=20;
	if(PID_I<=-20) PID_I=-20;
	//--------------------------
	motorb = (int)(33+( PID_P*0.07+PID_I*0.01));	
	motora = (int)(47-( PID_P*0.07+PID_I*0.01));
	//--------------------------
	if(motorb>=50) motorb=50;
	if(motorb<=10) motorb=10;
	if(motora>=50) motora=50;
	if(motora<=10) motora=10;	
}

void PID_CONTROL_5550(fp32 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
{
	PID_N=Value;
	//--------------------------
	PID_P=Target-PID_N;
	//--------------------------
	PID_I+=PID_P;
	//--------------------------
	if(PID_I>=20) PID_I=20;
	if(PID_I<=-20) PID_I=-20;
	//--------------------------
	motorb = (int)(32+( PID_P*0.1+PID_I*0.01));	
	motora = (int)(45+( PID_P*0.1+PID_I*0.01));
	//--------------------------
	if(motorb>=50) motorb=50;
	if(motorb<=10) motorb=10;
	if(motora>=50) motora=50;
	if(motora<=10) motora=10;	
}

void PID_CONTROL_9590(fp32 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
{
	PID_N=Value;
	//--------------------------
	PID_P=Target-PID_N;
	//--------------------------
	PID_I+=PID_P;
	//--------------------------
	if(PID_I>=20) PID_I=20;
	if(PID_I<=-20) PID_I=-20;
	//--------------------------
	motorb = (int)(43+( PID_P*0.2+PID_I*0.05));	
	motora = (int)(17-( PID_P*0.15+PID_I*0.05));
	//--------------------------
	if(motorb>=50) motorb=50;
	if(motorb<=10) motorb=10;
	if(motora>=43) motora=43;
	if(motora<=10) motora=10;
	Delay(1);
}

void PID_CONTROL_10095(fp32 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
{
	PID_N=Value;
	//--------------------------
	PID_P=Target-PID_N;
	//--------------------------
	PID_I+=PID_P;
	//--------------------------
	if(PID_I>=20) PID_I=20;
	if(PID_I<=-20) PID_I=-20;
	//--------------------------
	motorb = (int)(43+( PID_P*0.2+PID_I*0.05));	
	motora = (int)(16-( PID_P*0.15+PID_I*0.05));
	//--------------------------
	if(motorb>=50) motorb=50;
	if(motorb<=10) motorb=10;
	if(motora>=45) motora=45;
	if(motora<=10) motora=10;
	Delay(1);	
}

void PID_CONTROL_105100(fp32 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
{
	PID_N=Value;
	//--------------------------
	PID_P=Target-PID_N;
	//--------------------------
	PID_I+=PID_P;
	//--------------------------
	if(PID_I>=20) PID_I=20;
	if(PID_I<=-20) PID_I=-20;
	//--------------------------
	motorb = (int)(45+( PID_P*0.1+PID_I*0.1));	
	motora = (int)(36-( PID_P*0.1+PID_I*0.1));
	//--------------------------
	if(motorb>=50) motorb=50;
	if(motorb<=10) motorb=10;
	if(motora>=50) motora=50;
	if(motora<=10) motora=10;	
	Delay(1);
}

void PID_CONTROL_110105(fp32 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
{
	PID_N=Value;
	//--------------------------
	PID_P=Target-PID_N;
	//--------------------------
	PID_I+=PID_P;
	//--------------------------
	if(PID_I>=20) PID_I=20;
	if(PID_I<=-20) PID_I=-20;
	//--------------------------
	motorb = (int)(47+( PID_P*0.15+PID_I*0.15));	
	motora = (int)(32-( PID_P*0.15+PID_I*0.15));
	//--------------------------
	if(motorb>=50) motorb=50;
	if(motorb<=10) motorb=10;
	if(motora>=50) motora=50;
	if(motora<=10) motora=10;	
	Delay(1);
}

void PID_CONTROL_115110(fp32 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
{
	PID_N=Value;
	//--------------------------
	PID_P=Target-PID_N;
	//--------------------------
	PID_I+=PID_P;
	//--------------------------
	PID_D=PID_P-TEMP_D;
	if(PID_I>=20) PID_I=20;
	if(PID_I<=-20) PID_I=-20;
	//--------------------------
	motorb = (int)(33-( PID_P*0.1+PID_D*0.2));	
	motora = (int)(14+( PID_P*0.1+PID_D*0.2));
	//--------------------------
	if(motorb>=50) motorb=50;
	if(motorb<=10) motorb=10;
	if(motora>=50) motora=50;
	if(motora<=10) motora=10;	
	Delay(1);
	TEMP_D=PID_P;
}

void PID_CONTROL_120115(fp32 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
{
	PID_N=Value;
	//--------------------------
	PID_P=Target-PID_N;
	//--------------------------
	PID_I+=PID_P;
	//--------------------------
	PID_D=PID_P-TEMP_D;
	if(PID_I>=20) PID_I=20;
	if(PID_I<=-20) PID_I=-20;
	//--------------------------
	motorb = (int)(47+( PID_P*0.1+PID_I*0.05+PID_D*0.9));	
	motora = (int)(42-( PID_P*0.1+PID_I*0.05+PID_D*0.9));
	//--------------------------
	if(motorb>=50) motorb=50;
	if(motorb<=10) motorb=10;
	if(motora>=50) motora=50;
	if(motora<=10) motora=10;
	TEMP_D=PID_P;	
}

void PID_CONTROL_GEN1(fp32 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
{
	PID_N=Value;
	//--------------------------
	PID_P=Target-PID_N;
	//--------------------------
	PID_I+=PID_P;
	//--------------------------
	PID_D=PID_P-TEMP_D;
	if(PID_I>=50) PID_I=50;
	if(PID_I<=-50) PID_I=-50;
	//--------------------------
	motorb = 18+(int)( PID_P*0.1+PID_D*1);	
	motora = 45-(int)( PID_P*0.1+PID_D*1);
	//--------------------------
	if(motorb>=50) motorb=50;
	if(motorb<=10) motorb=10;
	if(motora>=50) motora=50;
	if(motora<=10) motora=10;
	TEMP_D=PID_P;
}

void PID_CONTROL_GEN2(fp32 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
{
	PID_N=Value;
	//--------------------------
	PID_P=Target-PID_N;
	//--------------------------
	PID_I+=PID_P;
	//--------------------------
	PID_D=PID_P-TEMP_D;
	if(PID_I>=50) PID_I=50;
	if(PID_I<=-50) PID_I=-50;
	//--------------------------
	motorb = 30+(int)( PID_P*0.1+PID_D*1);	
	motora = 30-(int)( PID_P*0.1+PID_D*1);
	//--------------------------
	if(motorb>=50) motorb=50;
	if(motorb<=10) motorb=10;
	if(motora>=50) motora=50;
	if(motora<=10) motora=10;
	TEMP_D=PID_P;
}

void PID_CONTROL_GEN3(uint8 Target,fp32 Value)			 //Target-Ŀ��ֵ��Value����ֵ
{
	PID_N=Value;
	//--------------------------
	PID_P=Target-PID_N;
	//--------------------------
	PID_I+=PID_P;
	//--------------------------
	PID_D=PID_P-TEMP_D;
	PID_D=PID_P-TEMP_D;
	if(PID_I>=50) PID_I=50;
	if(PID_I<=-50) PID_I=-50;
	//--------------------------
	motorb = 45+(int)( PID_P*0.1+PID_D*1);	
	motora = 18-(int)( PID_P*0.1+PID_D*1);
	//--------------------------
	if(motorb>=50) motorb=50;
	if(motorb<=10) motorb=10;
	if(motora>=50) motora=50;
	if(motora<=10) motora=10;
	TEMP_D=PID_P;
}

void set1()
{
	motorb=21;
	motora=50;
}

void set2()
{
	motorb=21;
	motora=50;
}

void set3()
{
	motorb=22;
	motora=50;
}
void set4()
{
	motorb=23;
	motora=50;
}

void set5()
{
	motorb=24;
	motora=50;
}
void set6()
{
	motorb=25;
	motora=50;
}

void set7()
{
	motorb=26;
	motora=50;
}
void set8()
{
	motorb=27;
	motora=50;
}

void set9()
{
	motorb=28;
	motora=50;
}
void set10()
{
	motorb=29;
	motora=50;
}




void set11()
{
	motorb=30;
	motora=50;
}

void set12()
{
	motorb=31;
	motora=50;
}

void set13()
{
	motorb=32;
	motora=40;
}

void set14()
{
	motorb=33;
	motora=40;
}
void set15()
{
	motorb=34;
	motora=40;
}

void set16()
{
	motorb=36;
	motora=40;
}
void set17()
{
	motorb=37;
	motora=40;
}

void set18()
{
	motorb=38;
	motora=40;
}

void set19()
{
	motorb=39;
	motora=40;
}




void set20()
{
	motorb=40;
	motora=40;
}

void set21()
{
	motorb=40;
	motora=38;
}

void set22()
{
	motorb=40;
	motora=36;
}
void set23()
{
	motorb=40;
	motora=35;
}

void set24()
{
	motorb=40;
	motora=34;
}
void set25()
{
	motorb=40;
	motora=33;
}

void set26()
{
	motorb=42;
	motora=33;
}
void set27()
{
	motorb=50;
	motora=31;
}

void set28()
{
	motorb=50;
	motora=29;
}
void set29()
{
	motorb=50;
	motora=28;
}
void set30()
{
	motorb=50;
	motora=27;
}

void set31()
{
	motorb=50;
	motora=26;
}

void set32()
{
	motorb=50;
	motora=24;
}

void set33()
{
	motorb=50;
	motora=22;
}
void set34()
{
	motorb=50;
	motora=21;
}

void set35()
{
	motorb=50;
	motora=20;
}
void set36()
{
	motorb=50;
	motora=19;
}

void set37()
{
	motorb=40;
	motora=19;
}

//=======================================================================
//--------------------------End of PID_CONTROL.C---------------------------------
//=======================================================================
