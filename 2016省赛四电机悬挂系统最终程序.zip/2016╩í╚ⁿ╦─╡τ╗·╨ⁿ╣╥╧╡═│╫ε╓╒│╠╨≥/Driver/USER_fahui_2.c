/************************************************************************/
/*********                      New.C                       *************/
/**********          Written By ZQW---20130117              *************/
/**********                  Version 1.0			      ***************/
/************************************************************************/
#include "STC15.H"
#include "DataForm_STC15.H"
#include "USER_fahui_2.h"
#include "LCD_1602.H"
#include "KEY.H"
#include "motor_stc15.h"

uint16 key_count3 = 45;
uint8 angle1 = 1;		//ģʽ1�Ƕ��趨

//-----------------------------------------------------------------------
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//-----------------------------------------------------------------------
//----------------------����˵��-----------------------------------------
/*																	   */
//-----------------------------------------------------------------------
//=======================================================================

//-----------------------------------------------------------------------
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//-----------------------------------------------------------------------
//----------------------���ݱ�������-------------------------------------
//-----------------------------------------------------------------------
//=======================================================================
void USER_fahui()
{
	WriteCommandLCM(0x01, 1);
	DisplayListChar(0, 0, "set:", 4);
	while(angle1)
	{
		if(Read_KEY2()) key_count3++;
		if(Read_KEY3()) key_count3--;
		if(key_count3>=360)	key_count3=0;
		Delay(3);
		lcd_printf(dis, key_count3);
		DisplayListChar(5, 0, dis, 4);
		if(Read_KEY4())	 angle1=0;
	}
	angle1=1;
	
	Delay(6);
	Enable_Timer2_INT();
	while(Flag_fahui1_set--)
	{	
//-----------------------------------------------------------------------
	    if(0<=key_count3 && key_count3<90)
		{
			Stepa=10;
			Stepb=0;					
			if(key_count3>=85) Run_y1();
			else
		    {
				Hudu = (key_count3*3.14)/180;
				Stepb = tan(Hudu)*Stepa;	
				run_0_90();
			}
		}

		if(90<=key_count3 && key_count3<180)
		{
			Stepa=10;
			Stepb=0;
			key_count32 = key_count3-90;
			if(key_count32>=85) Run_x2();
			else
		    {
				Hudu = (key_count32*3.14)/180;
				Stepb = tan(Hudu)*Stepa;	
				run_90_180();
			}
		}

		if(180<=key_count3 && key_count3<270)
		{
			Stepa=10;
			Stepb=0;
			key_count33 = key_count3-180;
			if(key_count33>=85) Run_y2();
			else
		    {
				Hudu = (key_count33*3.14)/180;
				Stepb = tan(Hudu)*Stepa;	
				run_180_270();
			}
		}

		if(270<=key_count3 && key_count3<360)
		{
			Stepa=10;
			Stepb=0;
			key_count34 = key_count3-270;
			if(key_count34>=85) Run_x1();
			else
		    {
				Hudu = (key_count34*3.14)/180;
				Stepb = tan(Hudu)*Stepa;	
				run_270_360();
			}
		}


//-----------------------------------------------------------------------------------
		if(Timer_motor>=5000)
		{
			Disable_Timer2_INT();
			Timer_motor = 0;						
			Stop_toger();
			Delay(44);
			Enable_Timer2_INT();
			while(Flag_fahui2_set)
			{
			    if(0<=key_count3 && key_count3<90)
				{
					Stepa=10;
					Stepb=0;					
					if(key_count3>=85) Run_y1();
					else
				    {
						Hudu = (key_count3*3.14)/180;
						Stepb = tan(Hudu)*Stepa;	
						run_180_270();
					}
				}

				if(90<=key_count3 && key_count3<180)
				{
					Stepa=10;
					Stepb=0;
					key_count32 = key_count3-90;
					if(key_count32>=85) Run_x2();
					else
				    {
						Hudu = (key_count32*3.14)/180;
						Stepb = tan(Hudu)*Stepa;	
						run_270_360();
					}
				}

				if(180<=key_count3 && key_count3<270)
				{
					Stepa=10;
					Stepb=0;
					key_count33 = key_count3-180;
					if(key_count33>=85) Run_y2();
					else
				    {
						Hudu = (key_count33*3.14)/180;
						Stepb = tan(Hudu)*Stepa;	
						run_0_90();
					}
				}

				if(270<=key_count3 && key_count3<360)
				{
					Stepa=10;
					Stepb=0;
					key_count34 = key_count3-270;
					if(key_count34>=85) Run_x1();
					else
				    {
						Hudu = (key_count34*3.14)/180;
						Stepb = tan(Hudu)*Stepa;	
						run_90_180();
					}
				}

				if(Timer_motor>=5000)
				{
					Disable_Timer2_INT();
					Timer_motor = 0;						
					Stop_toger();
					Flag_fahui2_set = 0;
					modle_1();								
				}
			}						
		}
/********************************************************************/
/*******************************************************************/
		while(Flag_fahui3_set)
		{		
			 if(0<=key_count3 && key_count3<90)
			{
				Stepa=10;
				Stepb=0;					
				if(key_count3>=85) Run_y2();
				else
			    {
					Hudu = (key_count3*3.14)/180;
					Stepb = tan(Hudu)*Stepa;	
					run_180_270();
				}
			}
	
			if(90<=key_count3 && key_count3<180)
			{
				Stepa=10;
				Stepb=0;
				key_count32 = key_count3-90;
				if(key_count32>=85) Run_x1();
				else
			    {
					Hudu = (key_count32*3.14)/180;
					Stepb = tan(Hudu)*Stepa;	
					run_270_360();
				}
			}
	
			if(180<=key_count3 && key_count3<270)
			{
				Stepa=10;
				Stepb=0;
				key_count33 = key_count3-180;
				if(key_count33>=85) Run_y1();
				else
			    {
					Hudu = (key_count33*3.14)/180;
					Stepb = tan(Hudu)*Stepa;	
					run_0_90();
				}
			}
	
			if(270<=key_count3 && key_count3<360)
			{
				Stepa=10;
				Stepb=0;
				key_count34 = key_count3-270;
				if(key_count34>=85) Run_x2();
				else
			    {
					Hudu = (key_count34*3.14)/180;
					Stepb = tan(Hudu)*Stepa;	
					run_90_180();
				}
			}


//-----------------------------------------------------------------------------------
			if(Timer_motor>=5000)
			{
				Disable_Timer2_INT();
				Timer_motor = 0;						
				Stop_toger();
				Delay(44);
				Enable_Timer2_INT();
				while(Flag_fahui4_set)
				{
				    if(0<=key_count3 && key_count3<90)
					{
						Stepa=10;
						Stepb=0;					
						if(key_count3>=85) Run_y1();
						else
					    {
							Hudu = (key_count3*3.14)/180;
							Stepb = tan(Hudu)*Stepa;	
							run_180_270();
						}
					}
	
					if(90<=key_count3 && key_count3<180)
					{
						Stepa=10;
						Stepb=0;
						key_count32 = key_count3-90;
						if(key_count32>=85) Run_x2();
						else
					    {
							Hudu = (key_count32*3.14)/180;
							Stepb = tan(Hudu)*Stepa;	
							run_270_360();
						}
					}
	
					if(180<=key_count3 && key_count3<270)
					{
						Stepa=10;
						Stepb=0;
						key_count33 = key_count3-180;
						if(key_count33>=85) Run_y2();
						else
					    {
							Hudu = (key_count33*3.14)/180;
							Stepb = tan(Hudu)*Stepa;	
							run_0_90();
						}
					}
	
					if(270<=key_count3 && key_count3<360)
					{
						Stepa=10;
						Stepb=0;
						key_count34 = key_count3-270;
						if(key_count34>=85) Run_x1();
						else
					    {
							Hudu = (key_count34*3.14)/180;
							Stepb = tan(Hudu)*Stepa;	
							run_90_180();
						}
					}
	
					if(Timer_motor>=5000)
					{
						Disable_Timer2_INT();
						Timer_motor = 0;						
						Stop_toger();
						Flag_fahui3_set = 0;
						Flag_fahui4_set = 0;							
					}
				}						
			}
		}					
	}
	Flag_fahui1_set = 4;
	Flag_fahui2_set = 1;
	Flag_fahui3_set = 1;
	Flag_fahui4_set = 1;
}

//-----------------------------------------------------------------------
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//-----------------------------------------------------------------------
//----------------------���庯��ʵ��-------------------------------------
//-----------------------------------------------------------------------
//=======================================================================

//=======================================================================
//--------------------------End of New.C---------------------------------
//=======================================================================
