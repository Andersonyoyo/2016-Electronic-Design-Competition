/************************************************************************/
/*********                     main.C                       *************/
/**********          Written By ZQW---20160715              *************/
/**********                  Version 1.0			      ***************/
/************************************************************************/
#include "Cfg_STC15.H"

#define	LED1 P55

uint8 key_count1 = 1;
int8 key_count2 = 20;
uint16 key_count3 = 45;
uint16 key_count32 = 45;
uint16 key_count33 = 45;
uint16 key_count34 = 45;
uint8 model = 1;		//ģʽ�趨
uint8 angle1 = 1;		//ģʽ1�Ƕ��趨

uint8 Flag_high_set = 1;
uint8 Flag_long_set = 1;
uint8 Flag_angle_set = 1;
uint8 Flag_time_set	= 5;
uint8 Flag_angle1_set = 1;
uint8 Flag_angle2_set = 1;
uint8 Flag_angle3_set = 1;
uint8 Flag_angle4_set = 1;
uint8 yuan_R = 1;
uint8 yuan_R_set = 1;
int16 motor_count =0 ;
int16 motor_counta = 0;
int16 motor_countb = 0;
uint8 yuan_run = 1;
uint16 yuan_o = 0;
fp32 Hudu_re = 0;
uint8 fahui_4_2 = 1;
uint8 fahui_4_1 = 1;
uint8 fahui_4_3	= 1;
uint8 fahui_4_4 = 1;
uint8 fahui_4_5 = 1;

uint8	Flag_fahui1_set = 4;
uint8	Flag_fahui2_set = 1;
uint8	Flag_fahui3_set = 1;
uint8	Flag_fahui4_set = 1;


int16 Angle_mod3 = 0;




//-----------------------------------------------------------------------
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//-----------------------------------------------------------------------
//----------------------���ݱ�������-------------------------------------
//-----------------------------------------------------------------------
//=======================================================================
void main()
{
	Outdate_gy25();
	InitGPIO_lcd();
	InitLcd();
	HC_SR04_GPIO();
	Timer0Init();
	Enble_T0();

	motor4_gpio();
	motor3_gpio();
	motor2_gpio();
	motor1_gpio();
	Timer2Init();

	Init_GPIO_KEY();

	P5M0&=~0x20;
	P5M1&=~0x20;
	LED1 = 1;

	while(1)
	{
		SeriPushSend(0XA5); 
        SeriPushSend(0X51);                                        //����1֡��ȡ���������ȡ 
		Display();
		Angle_x = ((YPR[1]+260)%10000/10);
		Angle_y = ((YPR[2]-8830)%10000/10);																
		lcd_printf(dis, Angle_x);			//ת��������ʾ		
		DisplayListChar(0, 0, dis, 4);			 
		lcd_printf(dis, Angle_y);			//ת��������ʾ
		DisplayListChar(6, 0, dis, 4);		

		high_cm = Distance_count(25);
		lcd_printf(dis, high_cm); 
		DisplayListChar(0, 1, dis, 4);

//		if(Read_KEY1())	 modle_1();
//		if(Read_KEY2())	 Run_y2();
//		if(Read_KEY3())	 Run_y1();
//		if(Read_KEY4())	 Run_y2();
		if(Read_KEY1())										//����ģʽ
		{	
			WriteCommandLCM(0x01, 1);			  //��ʾ����
			DisplayListChar(0, 0, "set mode", 8);
			while(model)
			{
				if(Read_KEY1())	 key_count1++;
				if(key_count1>9) key_count1=1;
				lcd_printf(dis, key_count1);
				DisplayListChar(9, 0, dis, 4);
				if(Read_KEY4())	 model=0;
				Delay(3);
			}
			model=1;

//ģʽ1------------------------------------------------
//----------------------------------------------------------

			Delay(6);
			if(key_count1==1)
			{
				WriteCommandLCM(0x01, 1);
				modle_1();
				LED1 = 0;
				Delay(44);
				LED1 = 1;	
			}

		
//ģʽ2------------------------------------------------------------
//------------------------------------------------------------
			Delay(6);
			if(key_count1==2)
			{
				WriteCommandLCM(0x01, 1);
				DisplayListChar(0, 0, "set:", 4);
				while(angle1)
				{
					if(Read_KEY2()) key_count2++;
					if(Read_KEY3()) key_count2--;
					Delay(3);
					lcd_printf(dis, key_count2);
					DisplayListChar(5, 0, dis, 4);
					if(Read_KEY4())	 angle1=0;
				}
				angle1=1;
				Delay(6);
				while(Flag_high_set)
				{
					high_cm = Distance_count(25);
					lcd_printf(dis, high_cm); 
					DisplayListChar(0, 1, dis, 4);

					if(high_cm > (key_count2)) Run_toger_dowm();
					if(high_cm < (key_count2-1)) Run_toger_up();
					if((key_count2-1)<=high_cm && high_cm<=(key_count2))
					{
						Stop_toger();
						Flag_high_set=0;
						LED1 = 0;
						Delay(44);
						LED1 = 1;
					} 
				}
				Flag_high_set = 1;	
			}


//-ģʽ3-------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

			Delay(6);
			if(key_count1==3)
			{
				WriteCommandLCM(0x01, 1);
				DisplayListChar(0, 0, "set:", 4);
				while(angle1)
				{
					if(Read_KEY2()) key_count2++;
					if(Read_KEY3()) key_count2--;
					Delay(3);
					lcd_printf(dis, key_count2);
					DisplayListChar(5, 0, dis, 4);
					if(Read_KEY4())	 angle1=0;
				}
				angle1=1;
				Delay(6);
				while(Flag_long_set)
				{
					SeriPushSend(0XA5); 
			        SeriPushSend(0X51);                                        //����1֡��ȡ���������ȡ 
					Display();
					Angle_y = ((YPR[2]-8830)%10000/10);																			 
					lcd_printf(dis, Angle_y);			//ת��������ʾ
					DisplayListChar(6, 0, dis, 4);	

					if(key_count2<=24 && key_count2>=-24) Angle_mod3= (int16)((12.23*key_count2)-1.389);
					if(key_count2>24) Angle_mod3= (int16)((8.133*key_count2)+88.31);
					if(key_count2<-24) Angle_mod3= (int16)((8.2*key_count2)-90.95);

					if(((YPR[2]-8830)%10000/10) > (Angle_mod3+4)) Run_y1();
					if(((YPR[2]-8830)%10000/10) < (Angle_mod3-4)) Run_y2();
					if((Angle_mod3-4)<=((YPR[2]-8830)%10000/10) && ((YPR[2]-8830)%10000/10)<=(Angle_mod3+4))
					{
						Stop_toger();
						Flag_long_set=0;
						LED1 = 0;
						Delay(44);
						LED1 = 1;
					} 
				}
				Flag_long_set = 1;	
			}


//-ģʽ4-------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------
//------------------------------------------------------------------------------------
		  	Delay(6);
			if(key_count1==4)
			{
				WriteCommandLCM(0x01, 1);
				DisplayListChar(0, 0, "set:", 4);
				while(angle1)
				{
					if(Read_KEY2()) key_count2++;
					if(Read_KEY3()) key_count2--;
					Delay(3);
					lcd_printf(dis, key_count2);
					DisplayListChar(5, 0, dis, 4);
					if(Read_KEY4())	 angle1=0;
				}
				angle1=1;
				
				Delay(6);
				while(Flag_angle_set)
				{
					SeriPushSend(0XA5); 
			        SeriPushSend(0X51);                                        //����1֡��ȡ���������ȡ 
					Display();
					Angle_y = ((YPR[2]-8830)%10000/10);																			 
					lcd_printf(dis, Angle_y);			//ת��������ʾ
					DisplayListChar(6, 0, dis, 4);	

					if(((YPR[2]-8830)%10000/100) > (key_count2)) Run_y1();
					if(((YPR[2]-8830)%10000/100) < (key_count2-1)) Run_y2();
					if((key_count2-1) <= ((YPR[2]-8830)%10000/100) && ((YPR[2]-8830)%10000/100) <= (key_count2))
					{
						Stop_toger();
						Flag_angle_set=0;
						LED1 = 0;
						Delay(44);
						LED1 = 1;
					} 
				}
				Flag_angle_set = 1;	
			}


//����2-------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------
//------------------------------------------------------------------------------------
		   	Delay(6);
			if(key_count1==6)
			{
//				while(Flag_time_set--)
//				{
////					SeriPushSend(0XA5); 
////			        SeriPushSend(0X51);                                        //����1֡��ȡ���������ȡ 
////					Display();
////					Angle_y = ((YPR[2]-8830)%10000/10);																			 
////					lcd_printf(dis, Angle_y);			//ת��������ʾ
////					DisplayListChar(6, 0, dis, 4);	
////
////					
////					while(!((-17 <= ((YPR[2]-8830)%10000/100)) && (((YPR[2]-8830)%10000/100) <= -15)))
////					{
////						SeriPushSend(0XA5); 
////				        SeriPushSend(0X51);                                        //����1֡��ȡ���������ȡ 
////						Display();
////					 	Run_y1();						
////					} 
////					Stop_toger();
////					Delay(44);
////					
////					while(!((15 <= ((YPR[2]-8830)%10000/100)) && (((YPR[2]-8830)%10000/100) <= 17)))
////					{
////						SeriPushSend(0XA5); 
////			       		SeriPushSend(0X51);                                        //����1֡��ȡ���������ȡ 
////						Display();
////					 	Run_y2();						
////					}
////					Stop_toger();
////					Delay(44);
////					LED1 = 0;
////					Delay(44);
////					LED1 = 1;
//				}
////				Flag_time_set = 5;
					WriteCommandLCM(0x01, 1);
					DisplayListChar(0, 0, "set:", 4);
					while(angle1)
					{
						if(Read_KEY2()) key_count3++;
						if(Read_KEY3()) key_count3--;
						if(key_count3>=360)	key_count3=0;
						Delay(3);
						lcd_printf(dis, key_count3);
						DisplayListChar(5, 0, dis, 4);
						if(Read_KEY4())	 angle1=0;
					}	
					angle1=1;
					Delay(6);			
				while(Flag_fahui1_set--)
				{
				
					Enable_Timer2_INT();
					while(Flag_angle1_set)
					{	
	//-----------------------------------------------------------------------
					    if(0<=key_count3 && key_count3<90)
						{
							Stepa=10;
							Stepb=0;					
							if(key_count3>=85) Run_y1();
							else
						    {
								Hudu = (key_count3*3.14)/180;
								Stepb = tan(Hudu)*Stepa;	
								run_0_90();
							}
						}
	
						if(90<=key_count3 && key_count3<180)
						{
							Stepa=10;
							Stepb=0;
							key_count32 = key_count3-90;
							if(key_count32>=85) Run_x2();
							else
						    {
								Hudu = (key_count32*3.14)/180;
								Stepb = tan(Hudu)*Stepa;	
								run_90_180();
							}
						}
	
						if(180<=key_count3 && key_count3<270)
						{
							Stepa=10;
							Stepb=0;
							key_count33 = key_count3-180;
							if(key_count33>=85) Run_y2();
							else
						    {
								Hudu = (key_count33*3.14)/180;
								Stepb = tan(Hudu)*Stepa;	
								run_180_270();
							}
						}
	
						if(270<=key_count3 && key_count3<360)
						{
							Stepa=10;
							Stepb=0;
							key_count34 = key_count3-270;
							if(key_count34>=85) Run_x1();
							else
						    {
								Hudu = (key_count34*3.14)/180;
								Stepb = tan(Hudu)*Stepa;	
								run_270_360();
							}
						}
	
	
	//-----------------------------------------------------------------------------------
						if(Timer_motor>=5000)
						{
							Disable_Timer2_INT();
							Timer_motor = 0;						
							Stop_toger();
							Delay(44);
							Enable_Timer2_INT();
							while(Flag_angle2_set)
							{
							    if(0<=key_count3 && key_count3<90)
								{
									Stepa=10;
									Stepb=0;					
									if(key_count3>=85) Run_y2();
									else
								    {
										Hudu = (key_count3*3.14)/180;
										Stepb = tan(Hudu)*Stepa;	
										run_180_270();
									}
								}
			
								if(90<=key_count3 && key_count3<180)
								{
									Stepa=10;
									Stepb=0;
									key_count32 = key_count3-90;
									if(key_count32>=85) Run_x1();
									else
								    {
										Hudu = (key_count32*3.14)/180;
										Stepb = tan(Hudu)*Stepa;	
										run_270_360();
									}
								}
			
								if(180<=key_count3 && key_count3<270)
								{
									Stepa=10;
									Stepb=0;
									key_count33 = key_count3-180;
									if(key_count33>=85) Run_y1();
									else
								    {
										Hudu = (key_count33*3.14)/180;
										Stepb = tan(Hudu)*Stepa;	
										run_0_90();
									}
								}
			
								if(270<=key_count3 && key_count3<360)
								{
									Stepa=10;
									Stepb=0;
									key_count34 = key_count3-270;
									if(key_count34>=85) Run_x2();
									else
								    {
										Hudu = (key_count34*3.14)/180;
										Stepb = tan(Hudu)*Stepa;	
										run_90_180();
									}
								}
	
								if(Timer_motor>=5000)
								{
									Disable_Timer2_INT();
									Timer_motor = 0;						
									Stop_toger();
									Flag_angle2_set = 0;
									Flag_angle1_set = 0;
//									modle_1();								
								}
							}						
						}					
					}
					Flag_angle1_set = 1;
					Flag_angle2_set = 1;

					/******************************************************************/
					/*******************************************************************/
					/*******************************************************************/

					Enable_Timer2_INT();
					while(Flag_angle3_set)
					{	
	//-----------------------------------------------------------------------
					    if(0<=key_count3 && key_count3<90)
						{
							Stepa=10;
							Stepb=0;					
							if(key_count3>=85) Run_y2();
							else
						    {
								Hudu = (key_count3*3.14)/180;
								Stepb = tan(Hudu)*Stepa;	
								run_180_270();
							}
						}
	
						if(90<=key_count3 && key_count3<180)
						{
							Stepa=10;
							Stepb=0;
							key_count32 = key_count3-90;
							if(key_count32>=85) Run_x1();
							else
						    {
								Hudu = (key_count32*3.14)/180;
								Stepb = tan(Hudu)*Stepa;	
								run_270_360();
							}
						}
	
						if(180<=key_count3 && key_count3<270)
						{
							Stepa=10;
							Stepb=0;
							key_count33 = key_count3-180;
							if(key_count33>=85) Run_y1();
							else
						    {
								Hudu = (key_count33*3.14)/180;
								Stepb = tan(Hudu)*Stepa;	
								run_0_90();
							}
						}
	
						if(270<=key_count3 && key_count3<360)
						{
							Stepa=10;
							Stepb=0;
							key_count34 = key_count3-270;
							if(key_count34>=85) Run_x2();
							else
						    {
								Hudu = (key_count34*3.14)/180;
								Stepb = tan(Hudu)*Stepa;	
								run_90_180();
							}
						}
	
	
	//-----------------------------------------------------------------------------------
						if(Timer_motor>=5000)
						{
							Disable_Timer2_INT();
							Timer_motor = 0;						
							Stop_toger();
							Delay(44);
							Enable_Timer2_INT();
							while(Flag_angle4_set)
							{
							    if(0<=key_count3 && key_count3<90)
								{
									Stepa=10;
									Stepb=0;					
									if(key_count3>=85) Run_y1();
									else
								    {
										Hudu = (key_count3*3.14)/180;
										Stepb = tan(Hudu)*Stepa;	
										run_0_90();
									}
								}
			
								if(90<=key_count3 && key_count3<180)
								{
									Stepa=10;
									Stepb=0;
									key_count32 = key_count3-90;
									if(key_count32>=85) Run_x2();
									else
								    {
										Hudu = (key_count32*3.14)/180;
										Stepb = tan(Hudu)*Stepa;	
										run_90_180();
									}
								}
			
								if(180<=key_count3 && key_count3<270)
								{
									Stepa=10;
									Stepb=0;
									key_count33 = key_count3-180;
									if(key_count33>=85) Run_y2();
									else
								    {
										Hudu = (key_count33*3.14)/180;
										Stepb = tan(Hudu)*Stepa;	
										run_180_270();
									}
								}
			
								if(270<=key_count3 && key_count3<360)
								{
									Stepa=10;
									Stepb=0;
									key_count34 = key_count3-270;
									if(key_count34>=85) Run_x1();
									else
								    {
										Hudu = (key_count34*3.14)/180;
										Stepb = tan(Hudu)*Stepa;	
										run_270_360();
									}
								}
	
								if(Timer_motor>=5000)
								{
									Disable_Timer2_INT();
									Timer_motor = 0;						
									Stop_toger();
									Flag_angle3_set = 0;
									Flag_angle4_set = 0;
									modle_1();								
								}
							}						
						}
						}
						Flag_angle3_set = 1;
						Flag_angle4_set	= 1;

					/******************************************************************/
					/*******************************************************************/
					/*******************************************************************/

				}
				Flag_fahui1_set = 4;
				LED1 = 0;
				Delay(44);
				LED1 = 1;	
		    }


//����1-------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------
//------------------------------------------------------------------------------------
			Delay(6);
			if(key_count1==5)
			{
				WriteCommandLCM(0x01, 1);
				DisplayListChar(0, 0, "set:", 4);
				while(angle1)
				{
					if(Read_KEY2()) key_count3++;
					if(Read_KEY3()) key_count3--;
					if(key_count3>=360)	key_count3=0;
					Delay(3);
					lcd_printf(dis, key_count3);
					DisplayListChar(5, 0, dis, 4);
					if(Read_KEY4())	 angle1=0;
				}
				angle1=1;
				
				Delay(6);
				Enable_Timer2_INT();
				while(Flag_angle1_set)
				{	
//-----------------------------------------------------------------------
				    if(0<=key_count3 && key_count3<90)
					{
						Stepa=10;
						Stepb=0;					
						if(key_count3>=85) Run_y1();
						else
					    {
							Hudu = (key_count3*3.14)/180;
							Stepb = tan(Hudu)*Stepa;	
							run_0_90();
						}
					}

					if(90<=key_count3 && key_count3<180)
					{
						Stepa=10;
						Stepb=0;
						key_count32 = key_count3-90;
						if(key_count32>=85) Run_x2();
						else
					    {
							Hudu = (key_count32*3.14)/180;
							Stepb = tan(Hudu)*Stepa;	
							run_90_180();
						}
					}

					if(180<=key_count3 && key_count3<270)
					{
						Stepa=10;
						Stepb=0;
						key_count33 = key_count3-180;
						if(key_count33>=85) Run_y2();
						else
					    {
							Hudu = (key_count33*3.14)/180;
							Stepb = tan(Hudu)*Stepa;	
							run_180_270();
						}
					}

					if(270<=key_count3 && key_count3<360)
					{
						Stepa=10;
						Stepb=0;
						key_count34 = key_count3-270;
						if(key_count34>=85) Run_x1();
						else
					    {
							Hudu = (key_count34*3.14)/180;
							Stepb = tan(Hudu)*Stepa;	
							run_270_360();
						}
					}


//-----------------------------------------------------------------------------------
					if(Timer_motor>=5000)
					{
						Disable_Timer2_INT();
						Timer_motor = 0;						
						Stop_toger();
						Delay(44);
						Enable_Timer2_INT();
						while(Flag_angle2_set)
						{
						    if(0<=key_count3 && key_count3<90)
							{
								Stepa=10;
								Stepb=0;					
								if(key_count3>=85) Run_y2();
								else
							    {
									Hudu = (key_count3*3.14)/180;
									Stepb = tan(Hudu)*Stepa;	
									run_180_270();
								}
							}
		
							if(90<=key_count3 && key_count3<180)
							{
								Stepa=10;
								Stepb=0;
								key_count32 = key_count3-90;
								if(key_count32>=85) Run_x1();
								else
							    {
									Hudu = (key_count32*3.14)/180;
									Stepb = tan(Hudu)*Stepa;	
									run_270_360();
								}
							}
		
							if(180<=key_count3 && key_count3<270)
							{
								Stepa=10;
								Stepb=0;
								key_count33 = key_count3-180;
								if(key_count33>=85) Run_y1();
								else
							    {
									Hudu = (key_count33*3.14)/180;
									Stepb = tan(Hudu)*Stepa;	
									run_0_90();
								}
							}
		
							if(270<=key_count3 && key_count3<360)
							{
								Stepa=10;
								Stepb=0;
								key_count34 = key_count3-270;
								if(key_count34>=85) Run_x2();
								else
							    {
									Hudu = (key_count34*3.14)/180;
									Stepb = tan(Hudu)*Stepa;	
									run_90_180();
								}
							}

							if(Timer_motor>=5000)
							{
								Disable_Timer2_INT();
								Timer_motor = 0;						
								Stop_toger();
								Flag_angle2_set = 0;
								Flag_angle1_set = 0;
								modle_1();
								LED1 = 0;
								Delay(44);
								LED1 = 1;								
							}
						}						
					}					
				}
				Flag_angle1_set = 1;
				Flag_angle2_set = 1;
			}


//����4-------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------
//------------------------------------------------------------------------------------
			Delay(6);
			if(key_count1==8)
			{
				while(fahui_4_1)
				{
					SeriPushSend(0XA5); 
			        SeriPushSend(0X51);                                        //����1֡��ȡ���������ȡ 
					Display();
					B_run_1();
					Angle_mod3= (int16)((12.23*(-15))-1.389);
					if((Angle_mod3-4)<((YPR[2]-8830)%10000/10) && (Angle_mod3+4)>((YPR[2]-8830)%10000/10)) 
					{
						Stop_toger();
					   	fahui_4_1 = 0;
					}
				}
				while(fahui_4_2)
				{
					SeriPushSend(0XA5); 
			        SeriPushSend(0X51);                                        //����1֡��ȡ���������ȡ 
					Display();
					A_run_2();
					Angle_mod3= (int16)((12.23*10)-1.389);
					if((Angle_mod3-4)<((YPR[1]+260)%10000/10) && (Angle_mod3+4)>((YPR[1]+260)%10000/10)) 
					{
						Stop_toger();
					   	fahui_4_2 = 0;
					}
				}
				while(fahui_4_3)
				{
					SeriPushSend(0XA5); 
			        SeriPushSend(0X51);                                        //����1֡��ȡ���������ȡ 
					Display();
					B_run_2();
					Angle_mod3= (int16)((12.23*5)-1.389);
					if((Angle_mod3-4)<((YPR[2]-8830)%10000/10) && (Angle_mod3+4)>((YPR[2]-8830)%10000/10)) 
					{
						Stop_toger();
					   	fahui_4_3 = 0;
					}
				}
				Enable_Timer2_INT();
				while(fahui_4_4)
				{
					B_run_2();
					A_run_1();
					if(Timer_motor>=10000) 
					{
						Disable_Timer2_INT();
						Timer_motor = 0;
						Stop_toger();
					   	fahui_4_4 = 0;
					}
				}
				while(fahui_4_5)
				{
					SeriPushSend(0XA5); 
			        SeriPushSend(0X51);                                        //����1֡��ȡ���������ȡ 
					Display();
					B_run_1();
					Angle_mod3= (int16)((12.23*(-16))-1.389);
					if((Angle_mod3-4)<((YPR[2]-8830)%10000/10) && (Angle_mod3+4)>((YPR[2]-8830)%10000/10)) 
					{
						Stop_toger();
					   	fahui_4_5 = 0;
					}
				}
				modle_1();
				LED1 = 0;
				Delay(44);
				LED1 = 1;
			}
			fahui_4_1 = 1;
			fahui_4_2 = 1;
			fahui_4_3 = 1;
			fahui_4_4 = 1;
			fahui_4_5 = 1;


//����3-------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------
//------------------------------------------------------------------------------------
			Delay(6);
			if(key_count1==7)
			{
			    WriteCommandLCM(0x01, 1);
				DisplayListChar(0, 0, "set:", 4);
				while(yuan_R)
				{
					if(Read_KEY2()) key_count2++;
					if(Read_KEY3()) key_count2--;
					Delay(3);
					lcd_printf(dis, key_count2);
					DisplayListChar(5, 0, dis, 4);
					if(Read_KEY4())	 yuan_R=0;
				}

				if(key_count2<=24 && key_count2>=-24) Angle_mod3= (int16)((12.23*key_count2)-1.389);
				if(key_count2>24) Angle_mod3= (int16)((8.133*key_count2)+88.31);
				
				motor_count = 0;
				while(yuan_R_set)
				{
					SeriPushSend(0XA5); 
			        SeriPushSend(0X51);                                        //����1֡��ȡ���������ȡ 
					Display();
					Angle_x = ((YPR[1]+260)%10000/10);
					Angle_y = ((YPR[2]-8830)%10000/10);	
					lcd_printf(dis, motor_count);
					DisplayListChar(5, 0, dis, 4);
					if(((YPR[2]-8830)%10000/10) < (Angle_mod3)) 
					{
						B_run_2();
						motor_count++;
					}
					if((Angle_mod3-4)<=((YPR[2]-8830)%10000/10) && ((YPR[2]-8830)%10000/10)<=(Angle_mod3+4)) 
					{
						Stop_toger(); 
					 	yuan_R_set = 0;
					}
				}
				yuan_o = 0;
				Hudu_re = 0;
				while(yuan_run)
				{
					yuan_o = yuan_o + 4;
					Hudu = (yuan_o*3.14)/180;
				
					motor_counta = (sin(Hudu)*motor_count) - (sin(Hudu_re)*motor_count);
					motor_countb = (cos(Hudu)*motor_count) - (cos(Hudu_re)*motor_count);

					motor_recent1 = motor_counta;
					motor_recent2 = motor_countb;		
					Hudu_re = Hudu;

					if(yuan_o>=0 && yuan_o<=90) yuan_0_90();
					if(yuan_o>90 && yuan_o<=180) yuan_90_180();
					if(yuan_o>180 && yuan_o<=270) yuan_180_270();
					if(yuan_o>270 && yuan_o<360) yuan_270_360();
					if(yuan_o>359) 
					{
						modle_1();
						yuan_run = 0;
						LED1 = 0;
						Delay(44);
						LED1 = 1;
					}
				}
			}
			yuan_run = 1;
			yuan_R_set = 1;
			yuan_R=1;
		}

		if(key_count1 == 9)
		{
			while(Flag_time_set--)
			{
				SeriPushSend(0XA5); 
		        SeriPushSend(0X51);                                        //����1֡��ȡ���������ȡ 
				Display();
				Angle_y = ((YPR[2]-8830)%10000/10);																			 
				lcd_printf(dis, Angle_y);			//ת��������ʾ
				DisplayListChar(6, 0, dis, 4);	

				
				while(!((-17 <= ((YPR[2]-8830)%10000/100)) && (((YPR[2]-8830)%10000/100) <= -15)))
				{
					SeriPushSend(0XA5); 
			        SeriPushSend(0X51);                                        //����1֡��ȡ���������ȡ 
					Display();
				 	Run_y1();						
				} 
				Stop_toger();
				Delay(44);
				
				while(!((15 <= ((YPR[2]-8830)%10000/100)) && (((YPR[2]-8830)%10000/100) <= 17)))
				{
					SeriPushSend(0XA5); 
		       		SeriPushSend(0X51);                                        //����1֡��ȡ���������ȡ 
					Display();
				 	Run_y2();						
				}
				Stop_toger();

			}
			Flag_time_set = 5;		
			
			LED1 = 0;
			Delay(44);
			LED1 = 1;
		}

////------------------------------------------------------------------
//----------------------------------------------------------------
////------------------------------------------------------------------
//----------------------------------------------------------------
////------------------------------------------------------------------
//----------------------------------------------------------------
////------------------------------------------------------------------
//----------------------------------------------------------------
	}
}

void Timer2() interrupt 12			//�ж��ڲ�����
{
	Timer_motor++;
}

	
//		if(Read_KEY1())										//����ģʽ
//		{	
//			WriteCommandLCM(0x01, 1);			  //��ʾ����
//			DisplayListChar(0, 0, "set mode", 8);
//			while(model)
//			{
//				if(Read_KEY1())	 key_count1++;
//				if(key_count1>2) key_count1=1;
//				lcd_printf(dis, key_count1);
//				DisplayListChar(9, 0, dis, 4);
//				if(Read_KEY4())	 model=0;
//				Delay(3);
//			}
//			model=1;
//
////ģʽ1------------------------------------------------
////----------------------------------------------------------
//
//			Delay(6);
//			if(key_count1==1)
//			{
//				WriteCommandLCM(0x01, 1);
//				modle_1();
//				LED1 = 0;
//				Delay(44);
//				LED1 = 1;	
//			}
//
////ģʽ2------------------------------------------------
////----------------------------------------------------------
//		
//		
//			Delay(6);
//			if(key_count1==2)
//			{
//				WriteCommandLCM(0x01, 1);
//				DisplayListChar(0, 0, "set:", 4);
//				while(angle1)
//				{
//					if(Read_KEY2()) key_count2++;
//					if(Read_KEY3()) key_count2--;
//					Delay(3);
//					lcd_printf(dis, key_count2);
//					DisplayListChar(5, 0, dis, 4);
//					if(Read_KEY4())	 angle1=0;
//				}
//				angle1=1;
//				Delay(6);
//				while(Flag_high_set)
//				{
//
//					if(high_cm > (key_count2+1)) Run_toger_dowm();
//					if(high_cm < (key_count2-1)) Run_toger_up();
//					if((key_count2-1)<=high_cm && high_cm<=(key_count2+1))
//					{
//						Stop_toger();
//						Flag_high_set=0;
//					} 
//				}	
//			}

//ģʽ3---------------------------------------------------------------
//--------------------------------------------------------------------

//	 	}
//		if(key_count1==2)
//		{
//			WriteCommandLCM(0x01, 1);
//			DisplayListChar(0, 0, "set:", 4);
//			while(angle2)
//			{
//				while(angle2_1)
//				{
//					if(Read_KEY2()) key_count2++;
//					if(Read_KEY3()) key_count2--;
//					lcd_printf(dis, key_count2);
//					DisplayListChar(5, 0, dis, 4);
//					if(Read_KEY4())	 angle2_1=0;
//				}
//				if(Read_KEY2()) key_count3++;
//				if(Read_KEY3()) key_count3--;
//				lcd_printf(dis, key_count3);
//				DisplayListChar(10, 0, dis, 4);
//				if(Read_KEY4())	 angle2=0;
//			}
//			angle2_1=1;
//			angle2=1;
//		}
//
//	}
//}


//void main()
//{
//	Outdate_gy25();
//	InitGPIO_lcd();
//	InitLcd();
//	HC_SR04_GPIO();
//	Timer0Init();
//	Enble_T0();
//	while(1)
//	{	
//		SeriPushSend(0XA5); 
//        SeriPushSend(0X51);                                        //����1֡��ȡ���������ȡ 
//		Display();														
//		lcd_printf(dis, ((YPR[1]+110)%10000/10));			//ת��������ʾ		
//		DisplayListChar(0, 0, dis, 4);			 
//		lcd_printf(dis, ((YPR[2]-8690)%10000/10));			//ת��������ʾ
//		DisplayListChar(0, 1, dis, 4);
//		lcd_printf(dis, Distance_count(25)); 
//		DisplayListChar(0, 1, dis, 4);
//		Delay(1);
//	}
//}

//			while(angle1)
//			{
//				if(Read_KEY2()) key_count2++;
//				if(Read_KEY3()) key_count2--;
//				Delay(3);
//				lcd_printf(dis, key_count2);
//				DisplayListChar(5, 0, dis, 4);
//				if(Read_KEY4())	 angle1=0;
//			}
//			angle1=



//=======================================================================
//--------------------------End of main.C--------------------------------
//=======================================================================
